<?php

$conn = mysqli_connect("localhost", "root", "70450289","weddingbudget");
//mysqli_select_db("weddingbudget",$conn);
if(!$conn)
echo "no connection established";



?>